#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <locale>

int main() {
    system("chcp 1251");
    setlocale(LC_ALL, "Russian");

    HANDLE h = CreateFile("file.txt", GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        std::cout << "���� ��� ����������. ������������? (y/n): ";
        char answer[10];
        fgets(answer, 10, stdin);
        if (answer[0] == 'y') {
            h = CreateFile("file.txt", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        }
    }
    if (h != INVALID_HANDLE_VALUE) {
        CloseHandle(h);
    }

    char s1[256], s2[256], s3[256];

    fgets(s1, 256, stdin);
    FILE* f = fopen("file.txt", "a");
    fputs(s1, f);
    fclose(f);

    fgets(s2, 256, stdin);
    f = fopen("file.txt", "r");
    std::string old;
    int c;
    while ((c = fgetc(f)) != EOF) {
        old += (char)c;
    }
    fclose(f);
    f = fopen("file.txt", "w");
    fputs(s2, f);
    fputs(old.c_str(), f);
    fclose(f);

    fgets(s3, 256, stdin);
    f = fopen("file.txt", "a");
    fputs(s3, f);
    fclose(f);

    std::ifstream in("file.txt");
    std::string line;
    while (std::getline(in, line)) {
        std::cout << line << std::endl;
    }
    in.close();

    return 0;
}
