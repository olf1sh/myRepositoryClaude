#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <locale>

int main() {
    system("chcp 1251");
    setlocale(LC_ALL, "Russian");

    HANDLE h = CreateFile("file.txt", GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        std::cout << "���� ��� ����������. ������������? (y/n): ";
        std::string answer;
        std::getline(std::cin, answer);
        if (answer == "y") {
            h = CreateFile("file.txt", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        }
    }
    if (h != INVALID_HANDLE_VALUE) {
        CloseHandle(h);
    }

    std::string s1, s2, s3;

    std::getline(std::cin, s1);
    FILE* f = fopen("file.txt", "a");
    fputs(s1.c_str(), f);
    fputs("\n", f);
    fclose(f);

    std::getline(std::cin, s2);
    f = fopen("file.txt", "r");
    std::string old;
    int c;
    while ((c = fgetc(f)) != EOF) {
        old += (char)c;
    }
    fclose(f);
    f = fopen("file.txt", "w");
    fputs(s2.c_str(), f);
    fputs("\n", f);
    fputs(old.c_str(), f);
    fclose(f);

    std::getline(std::cin, s3);
    f = fopen("file.txt", "a");
    fputs(s3.c_str(), f);
    fputs("\n", f);
    fclose(f);

    std::ifstream in("file.txt");
    std::string line;
    while (std::getline(in, line)) {
        std::cout << line << std::endl;
    }
    in.close();

    return 0;
}
